-- phpMyAdmin SQL Dump
-- version 3.3.2deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 23, 2011 at 04:27 PM
-- Server version: 5.1.41
-- PHP Version: 5.3.2-1ubuntu4.9

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `auto`
--

-- --------------------------------------------------------

--
-- Table structure for table `offers`
--

CREATE TABLE IF NOT EXISTS `offers` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `sysname` enum('auto','autochel','drom','e1','irr') NOT NULL,
  `source_id` varchar(255) NOT NULL,
  `source_url` varchar(255) NOT NULL,
  `status` tinyint(4) NOT NULL,
  `patterns_status` tinyint(4) NOT NULL,
  `dt_added` int(11) NOT NULL,
  `dt_last_found` int(11) NOT NULL,
  `mark` varchar(255) NOT NULL,
  `markmodel` varchar(255) NOT NULL,
  `price_rub` int(11) NOT NULL,
  `price_usd` int(11) NOT NULL,
  `price_eur` int(11) NOT NULL,
  `production_year` int(11) NOT NULL,
  `engine` varchar(10) NOT NULL,
  `engine_type` varchar(255) NOT NULL,
  `engine_type_id` int(11) NOT NULL,
  `drive` varchar(255) NOT NULL,
  `drive_id` int(11) NOT NULL,
  `transmission` varchar(255) NOT NULL,
  `transmission_id` int(11) NOT NULL,
  `right_steering_wheel` tinyint(4) NOT NULL,
  `run` int(11) NOT NULL,
  `vin` varchar(255) NOT NULL,
  `photo_exists` tinyint(4) NOT NULL,
  `body_type` varchar(255) NOT NULL,
  `body_type_id` int(11) NOT NULL,
  `color` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `without_customs` tinyint(4) NOT NULL,
  `available` tinyint(4) NOT NULL,
  `crashed` tinyint(4) NOT NULL,
  `details` text NOT NULL,
  `details_where` text NOT NULL,
  `package` text NOT NULL,
  `info` text NOT NULL,
  `contacts` text NOT NULL,
  `contact_person` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `phone2` varchar(255) NOT NULL,
  `photo_url` varchar(255) NOT NULL,
  `raw_html` text NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sysname` (`sysname`,`source_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `offers`
--


-- --------------------------------------------------------

--
-- Table structure for table `offers_body_types`
--

CREATE TABLE IF NOT EXISTS `offers_body_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `offers_body_types`
--

INSERT INTO `offers_body_types` (`id`, `name`) VALUES
(1, 'седан'),
(2, 'хэтчбек'),
(3, 'универсал'),
(4, 'купе'),
(5, 'внедорожник'),
(6, 'минивэн');

-- --------------------------------------------------------

--
-- Table structure for table `offers_drives`
--

CREATE TABLE IF NOT EXISTS `offers_drives` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `offers_drives`
--

INSERT INTO `offers_drives` (`id`, `name`) VALUES
(1, 'передний'),
(2, 'задний'),
(3, 'полный');

-- --------------------------------------------------------

--
-- Table structure for table `offers_engine_types`
--

CREATE TABLE IF NOT EXISTS `offers_engine_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `offers_engine_types`
--

INSERT INTO `offers_engine_types` (`id`, `name`) VALUES
(1, 'бензин'),
(2, 'дизель'),
(3, 'электрический');

-- --------------------------------------------------------

--
-- Table structure for table `offers_transmissions`
--

CREATE TABLE IF NOT EXISTS `offers_transmissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `offers_transmissions`
--

INSERT INTO `offers_transmissions` (`id`, `name`) VALUES
(1, 'автомат'),
(2, 'механика');

-- --------------------------------------------------------

--
-- Table structure for table `patterns`
--

CREATE TABLE IF NOT EXISTS `patterns` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sysname` enum('auto','autochel','drom','e1','irr') NOT NULL,
  `input_field` varchar(255) NOT NULL,
  `input_value` varchar(255) NOT NULL,
  `output_value` int(11) NOT NULL,
  `type` enum('equal','match') NOT NULL DEFAULT 'equal',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=29 ;

--
-- Dumping data for table `patterns`
--

INSERT INTO `patterns` (`id`, `sysname`, `input_field`, `input_value`, `output_value`, `type`) VALUES
(1, 'autochel', 'drive', 'задний', 2, 'equal'),
(2, 'autochel', 'drive', 'передний', 1, 'equal'),
(3, 'autochel', 'drive', 'полный', 3, 'equal'),
(4, 'autochel', 'engine_type', 'газ', 1, 'equal'),
(5, 'autochel', 'engine_type', 'бензин', 1, 'equal'),
(6, 'autochel', 'engine_type', 'дт', 2, 'equal'),
(7, 'autochel', 'engine_type', 'электро', 3, 'equal'),
(8, 'autochel', 'engine_type', 'гибрид', 1, 'equal'),
(9, 'autochel', 'engine_type', 'г-б', 1, 'equal'),
(10, 'autochel', 'transmission', 'Автомат', 1, 'equal'),
(11, 'autochel', 'transmission', 'Автомат', 1, 'equal'),
(12, 'autochel', 'transmission', 'Вариатор', 1, 'equal'),
(13, 'autochel', 'transmission', 'Робот', 1, 'equal'),
(14, 'autochel', 'transmission', 'Мех', 2, 'equal'),
(15, 'autochel', 'body_type', 'внедорожник', 5, 'equal'),
(16, 'autochel', 'body_type', 'кабриолет', 4, 'equal'),
(17, 'autochel', 'body_type', 'компактвэн', 6, 'equal'),
(18, 'autochel', 'body_type', 'кроссовер', 5, 'equal'),
(19, 'autochel', 'body_type', 'купе', 4, 'equal'),
(20, 'autochel', 'body_type', 'лимузин', 1, 'equal'),
(21, 'autochel', 'body_type', 'минивэн', 6, 'equal'),
(22, 'autochel', 'body_type', 'пикап', 5, 'equal'),
(23, 'autochel', 'body_type', 'родстер', 4, 'equal'),
(24, 'autochel', 'body_type', 'седан', 1, 'equal'),
(25, 'autochel', 'body_type', 'универсал', 3, 'equal'),
(26, 'autochel', 'body_type', 'фургон\r\n', 3, 'equal'),
(27, 'autochel', 'body_type', 'хетчбэк', 2, 'equal'),
(28, 'autochel', 'body_type', 'шасси', 5, 'equal');
